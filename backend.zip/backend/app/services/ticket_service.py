from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.models.models import Ticket
from app.schemas.schemas import TicketCreate, TicketStatusUpdate, TicketAssignUpdate


def create_ticket(db: Session, data: TicketCreate, customer_id: int) -> Ticket:
    ticket = Ticket(
        customer_id=customer_id,
        service_type=data.service_type,
        title=data.title,
        description=data.description,
        location=data.location,
        priority=data.priority,
        status="open",
    )
    db.add(ticket)
    db.commit()
    db.refresh(ticket)
    return ticket


def get_tickets_by_customer(db: Session, customer_id: int) -> list[Ticket]:
    return db.query(Ticket).filter(Ticket.customer_id == customer_id).all()


def get_all_tickets(db: Session) -> list[Ticket]:
    return db.query(Ticket).order_by(Ticket.created_at.desc()).all()


def get_ticket_by_id(db: Session, ticket_id: int) -> Ticket:
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    return ticket


def update_ticket_status(db: Session, ticket_id: int, data: TicketStatusUpdate) -> Ticket:
    ticket = get_ticket_by_id(db, ticket_id)
    ticket.status = data.status
    db.commit()
    db.refresh(ticket)
    return ticket


def assign_ticket(db: Session, ticket_id: int, data: TicketAssignUpdate) -> Ticket:
    ticket = get_ticket_by_id(db, ticket_id)
    ticket.assigned_technician = data.assigned_technician
    ticket.status = "in_progress"
    db.commit()
    db.refresh(ticket)
    return ticket
