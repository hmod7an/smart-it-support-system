import hashlib
import base64
from sqlalchemy.orm import Session

from app.models.models import User
from app.schemas.schemas import UserRegister


def hash_password(password: str) -> str:
    """SHA-256 hash — replaced by bcrypt in v2."""
    return hashlib.sha256(password.encode()).hexdigest()


def verify_password(plain: str, hashed: str) -> bool:
    return hash_password(plain) == hashed


def make_mock_token(user: User) -> str:
    """Phase 1 mock token: base64(email:role). Not cryptographically secure."""
    raw = f"{user.email}:{user.role}:{user.id}"
    return base64.b64encode(raw.encode()).decode()


def get_user_by_email(db: Session, email: str) -> User | None:
    return db.query(User).filter(User.email == email).first()


def register_user(db: Session, data: UserRegister) -> User:
    user = User(
        full_name=data.full_name,
        email=data.email,
        password_hash=hash_password(data.password),
        role="customer",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def seed_admin(db: Session) -> None:
    """Create the default admin account if it doesn't already exist."""
    existing = get_user_by_email(db, "admin@wsit.com")
    if not existing:
        admin = User(
            full_name="WSIT Administrator",
            email="admin@wsit.com",
            password_hash=hash_password("admin123"),
            role="admin",
        )
        db.add(admin)
        db.commit()
