from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime


# ── Auth Schemas ──────────────────────────────────────────────────────────────

class UserRegister(BaseModel):
    full_name: str
    email: EmailStr
    password: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(BaseModel):
    id: int
    full_name: str
    email: str
    role: str

    class Config:
        from_attributes = True


class LoginResponse(BaseModel):
    message: str
    token: str          # Phase 1: mock token (email-based); swap for JWT in v2
    user: UserResponse


# ── Ticket Schemas ────────────────────────────────────────────────────────────

class TicketCreate(BaseModel):
    service_type: str
    title: str
    description: str
    location: str
    priority: Optional[str] = "medium"


class TicketStatusUpdate(BaseModel):
    status: str


class TicketAssignUpdate(BaseModel):
    assigned_technician: str


class TicketResponse(BaseModel):
    id: int
    customer_id: int
    service_type: str
    title: str
    description: str
    location: str
    priority: str
    status: str
    assigned_technician: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    customer_name: Optional[str] = None

    class Config:
        from_attributes = True
