from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.database import get_db
from app.schemas.schemas import UserRegister, UserLogin, LoginResponse, UserResponse
from app.services import auth_service

router = APIRouter()


@router.post("/customers/register", response_model=UserResponse, status_code=201)
def register(data: UserRegister, db: Session = Depends(get_db)):
    """Register a new customer account."""
    if auth_service.get_user_by_email(db, data.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    user = auth_service.register_user(db, data)
    return user


@router.post("/auth/login", response_model=LoginResponse)
def login(data: UserLogin, db: Session = Depends(get_db)):
    """Authenticate a user and return a mock session token with role info."""
    user = auth_service.get_user_by_email(db, data.email)
    if not user or not auth_service.verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = auth_service.make_mock_token(user)
    return LoginResponse(
        message="Login successful",
        token=token,
        user=UserResponse(
            id=user.id,
            full_name=user.full_name,
            email=user.email,
            role=user.role,
        ),
    )
