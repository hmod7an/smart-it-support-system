from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from typing import Optional
import base64

from app.database.database import get_db
from app.schemas.schemas import (
    TicketCreate,
    TicketResponse,
    TicketStatusUpdate,
    TicketAssignUpdate,
)
from app.services import ticket_service
from app.services.auth_service import get_user_by_email

router = APIRouter()


# ── Token helpers (Phase 1 mock auth) ─────────────────────────────────────────

def decode_token(token: str) -> dict:
    """Decode the Phase 1 mock token → {email, role, id}."""
    try:
        raw = base64.b64decode(token.encode()).decode()
        email, role, uid = raw.split(":")
        return {"email": email, "role": role, "id": int(uid)}
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or missing token")


def get_current_user(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authorization header missing")
    token = authorization.split(" ", 1)[1]
    payload = decode_token(token)
    user = get_user_by_email(db, payload["email"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


def require_admin(user=Depends(get_current_user)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


# ── Ticket Endpoints ───────────────────────────────────────────────────────────

def _enrich(ticket, db) -> TicketResponse:
    """Attach customer_name to response."""
    resp = TicketResponse.model_validate(ticket)
    resp.customer_name = ticket.customer.full_name if ticket.customer else None
    return resp


@router.post("/tickets", response_model=TicketResponse, status_code=201)
def submit_ticket(
    data: TicketCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Customer submits a new service request ticket."""
    ticket = ticket_service.create_ticket(db, data, current_user.id)
    return _enrich(ticket, db)


@router.get("/tickets/my", response_model=list[TicketResponse])
def my_tickets(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Customer views their own tickets."""
    tickets = ticket_service.get_tickets_by_customer(db, current_user.id)
    return [_enrich(t, db) for t in tickets]


@router.get("/tickets", response_model=list[TicketResponse])
def all_tickets(
    db: Session = Depends(get_db),
    admin=Depends(require_admin),
):
    """Admin views all tickets."""
    tickets = ticket_service.get_all_tickets(db)
    return [_enrich(t, db) for t in tickets]


@router.get("/tickets/{ticket_id}", response_model=TicketResponse)
def ticket_detail(
    ticket_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Retrieve a single ticket by ID (owner or admin)."""
    ticket = ticket_service.get_ticket_by_id(db, ticket_id)
    if current_user.role != "admin" and ticket.customer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    return _enrich(ticket, db)


@router.put("/tickets/{ticket_id}/status", response_model=TicketResponse)
def update_status(
    ticket_id: int,
    data: TicketStatusUpdate,
    db: Session = Depends(get_db),
    admin=Depends(require_admin),
):
    """Admin updates the status of a ticket."""
    ticket = ticket_service.update_ticket_status(db, ticket_id, data)
    return _enrich(ticket, db)


@router.put("/tickets/{ticket_id}/assign", response_model=TicketResponse)
def assign_technician(
    ticket_id: int,
    data: TicketAssignUpdate,
    db: Session = Depends(get_db),
    admin=Depends(require_admin),
):
    """Admin assigns a technician to a ticket (sets status → in_progress)."""
    ticket = ticket_service.assign_ticket(db, ticket_id, data)
    return _enrich(ticket, db)
