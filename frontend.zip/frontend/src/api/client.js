import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:8000",
});

// Attach the Bearer token from localStorage to every request
API.interceptors.request.use((config) => {
  const token = localStorage.getItem("wsit_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default API;
