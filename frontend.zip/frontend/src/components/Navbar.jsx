import React from "react";
import { useNavigate } from "react-router-dom";

export default function Navbar({ title }) {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("wsit_user") || "null");

  function handleLogout() {
    localStorage.removeItem("wsit_token");
    localStorage.removeItem("wsit_user");
    navigate("/login");
  }

  return (
    <nav className="navbar">
      <h1>WSiT IT Support — {title}</h1>
      <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
        {user && (
          <span style={{ fontSize: "0.85rem", color: "#a0aec0" }}>
            {user.full_name} ({user.role})
          </span>
        )}
        <button onClick={handleLogout}>Logout</button>
      </div>
    </nav>
  );
}
