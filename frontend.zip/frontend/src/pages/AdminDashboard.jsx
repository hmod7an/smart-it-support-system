import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import StatusBadge from "../components/StatusBadge";
import API from "../api/client";

const STATUS_OPTIONS = ["open", "in_progress", "resolved", "closed"];

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [tickets, setTickets]           = useState([]);
  const [techInputs, setTechInputs]     = useState({});    // { [ticketId]: string }
  const [statusInputs, setStatusInputs] = useState({});    // { [ticketId]: string }
  const [feedback, setFeedback]         = useState({});    // { [ticketId]: string }

  async function fetchAll() {
    try {
      const { data } = await API.get("/tickets");
      setTickets(data);
    } catch {
      // handled by auth guard
    }
  }

  useEffect(() => { fetchAll(); }, []);

  async function handleAssign(ticketId) {
    const tech = techInputs[ticketId]?.trim();
    if (!tech) return;
    try {
      await API.put(`/tickets/${ticketId}/assign`, { assigned_technician: tech });
      setFeedback({ ...feedback, [ticketId]: "Assigned!" });
      fetchAll();
    } catch (err) {
      setFeedback({ ...feedback, [ticketId]: "Error assigning" });
    }
  }

  async function handleStatusUpdate(ticketId) {
    const status = statusInputs[ticketId];
    if (!status) return;
    try {
      await API.put(`/tickets/${ticketId}/status`, { status });
      setFeedback({ ...feedback, [ticketId]: "Status updated!" });
      fetchAll();
    } catch {
      setFeedback({ ...feedback, [ticketId]: "Error updating status" });
    }
  }

  // Summary counts
  const counts = tickets.reduce((acc, t) => {
    acc[t.status] = (acc[t.status] || 0) + 1;
    return acc;
  }, {});

  return (
    <>
      <Navbar title="Admin Dashboard" />
      <div className="container">

        {/* ── Summary Cards ── */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1rem", marginTop: "1.5rem" }}>
          {[
            { label: "Open",        key: "open",        color: "#4299e1" },
            { label: "In Progress", key: "in_progress", color: "#ed8936" },
            { label: "Resolved",    key: "resolved",    color: "#38a169" },
            { label: "Closed",      key: "closed",      color: "#718096" },
          ].map(({ label, key, color }) => (
            <div className="card" key={key} style={{ textAlign: "center", borderTop: `4px solid ${color}` }}>
              <div style={{ fontSize: "2rem", fontWeight: 700, color }}>{counts[key] || 0}</div>
              <div style={{ fontSize: "0.85rem", color: "#718096" }}>{label}</div>
            </div>
          ))}
        </div>

        {/* ── All Tickets Table ── */}
        <div className="dash-header">
          <h2>All Support Tickets</h2>
          <button className="btn btn-primary btn-sm" onClick={fetchAll}>Refresh</button>
        </div>

        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Customer</th>
                  <th>Title</th>
                  <th>Service</th>
                  <th>Priority</th>
                  <th>Status</th>
                  <th>Assigned To</th>
                  <th>Assign Technician</th>
                  <th>Update Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {tickets.map((t) => (
                  <tr key={t.id}>
                    <td>{t.id}</td>
                    <td>{t.customer_name || "—"}</td>
                    <td style={{ maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.title}</td>
                    <td>{t.service_type}</td>
                    <td><StatusBadge value={t.priority} /></td>
                    <td><StatusBadge value={t.status} /></td>
                    <td>{t.assigned_technician || "—"}</td>

                    {/* Assign technician inline */}
                    <td>
                      <div className="inline-form">
                        <input
                          placeholder="Technician name"
                          value={techInputs[t.id] || ""}
                          onChange={(e) => setTechInputs({ ...techInputs, [t.id]: e.target.value })}
                        />
                        <button className="btn btn-success btn-sm" onClick={() => handleAssign(t.id)}>Assign</button>
                      </div>
                    </td>

                    {/* Update status inline */}
                    <td>
                      <div className="inline-form">
                        <select
                          value={statusInputs[t.id] || t.status}
                          onChange={(e) => setStatusInputs({ ...statusInputs, [t.id]: e.target.value })}
                        >
                          {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                        </select>
                        <button className="btn btn-primary btn-sm" onClick={() => handleStatusUpdate(t.id)}>Save</button>
                      </div>
                      {feedback[t.id] && (
                        <span style={{ fontSize: "0.75rem", color: "#38a169" }}>{feedback[t.id]}</span>
                      )}
                    </td>

                    <td>
                      <button className="btn btn-primary btn-sm" onClick={() => navigate(`/tickets/${t.id}`)}>View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </>
  );
}
