import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import StatusBadge from "../components/StatusBadge";
import API from "../api/client";

export default function TicketDetails() {
  const { id }     = useParams();
  const navigate   = useNavigate();
  const [ticket, setTicket] = useState(null);
  const [error, setError]   = useState("");

  useEffect(() => {
    API.get(`/tickets/${id}`)
      .then(({ data }) => setTicket(data))
      .catch(() => setError("Ticket not found or access denied."));
  }, [id]);

  if (error) return (
    <>
      <Navbar title="Ticket Details" />
      <div className="container">
        <div className="card" style={{ marginTop: "2rem", textAlign: "center", color: "#e94560" }}>
          {error}
          <br />
          <button className="btn btn-primary" style={{ marginTop: "1rem" }} onClick={() => navigate(-1)}>Go Back</button>
        </div>
      </div>
    </>
  );

  if (!ticket) return (
    <>
      <Navbar title="Ticket Details" />
      <div className="container" style={{ paddingTop: "2rem", color: "#718096" }}>Loading…</div>
    </>
  );

  const rows = [
    ["Ticket ID", `#${ticket.id}`],
    ["Service Type", ticket.service_type],
    ["Location", ticket.location],
    ["Priority", <StatusBadge value={ticket.priority} />],
    ["Status", <StatusBadge value={ticket.status} />],
    ["Assigned Technician", ticket.assigned_technician || "Not yet assigned"],
    ["Submitted By", ticket.customer_name || "—"],
    ["Created", ticket.created_at ? new Date(ticket.created_at).toLocaleString() : "—"],
    ["Last Updated", ticket.updated_at ? new Date(ticket.updated_at).toLocaleString() : "—"],
  ];

  return (
    <>
      <Navbar title="Ticket Details" />
      <div className="container">
        <div style={{ margin: "1.5rem 0 0.5rem" }}>
          <button className="btn btn-primary btn-sm" onClick={() => navigate(-1)}>← Back</button>
        </div>

        <div className="card">
          <h2 style={{ marginBottom: "1.25rem", color: "#16213e" }}>{ticket.title}</h2>

          <table style={{ width: "100%", marginBottom: "1.25rem" }}>
            <tbody>
              {rows.map(([label, value]) => (
                <tr key={label}>
                  <td style={{ fontWeight: 600, width: "180px", padding: "0.45rem 0", color: "#4a5568", verticalAlign: "top" }}>{label}</td>
                  <td style={{ padding: "0.45rem 0" }}>{value}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div style={{ borderTop: "1px solid #e2e8f0", paddingTop: "1rem" }}>
            <p style={{ fontWeight: 600, color: "#4a5568", marginBottom: "0.4rem" }}>Description</p>
            <p style={{ lineHeight: 1.7, color: "#2d3748" }}>{ticket.description}</p>
          </div>
        </div>
      </div>
    </>
  );
}
