import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import API from "../api/client";

export default function LoginPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState("login");         // "login" | "register"
  const [form, setForm] = useState({ full_name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleLogin(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const { data } = await API.post("/auth/login", {
        email: form.email,
        password: form.password,
      });
      localStorage.setItem("wsit_token", data.token);
      localStorage.setItem("wsit_user", JSON.stringify(data.user));
      navigate(data.user.role === "admin" ? "/admin" : "/dashboard");
    } catch (err) {
      setError(err.response?.data?.detail || "Login failed");
    } finally {
      setLoading(false);
    }
  }

  async function handleRegister(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await API.post("/customers/register", form);
      setTab("login");
      setError("Registration successful! Please log in.");
    } catch (err) {
      setError(err.response?.data?.detail || "Registration failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-wrapper">
      <div className="login-box">
        <h2>WSiT Support Portal</h2>
        <p>Smart IT Service Request System</p>

        <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1.25rem" }}>
          {["login", "register"].map((t) => (
            <button
              key={t}
              className={`btn ${tab === t ? "btn-primary" : ""}`}
              style={{ flex: 1, background: tab === t ? "#4299e1" : "#edf2f7", color: tab === t ? "#fff" : "#4a5568" }}
              onClick={() => { setTab(t); setError(""); }}
            >
              {t === "login" ? "Login" : "Register"}
            </button>
          ))}
        </div>

        {tab === "login" ? (
          <form onSubmit={handleLogin}>
            <div className="form-group">
              <label>Email</label>
              <input name="email" type="email" value={form.email} onChange={handleChange} required placeholder="you@example.com" />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input name="password" type="password" value={form.password} onChange={handleChange} required placeholder="••••••••" />
            </div>
            <button className="btn btn-primary" style={{ width: "100%" }} disabled={loading}>
              {loading ? "Logging in…" : "Login"}
            </button>
          </form>
        ) : (
          <form onSubmit={handleRegister}>
            <div className="form-group">
              <label>Full Name</label>
              <input name="full_name" value={form.full_name} onChange={handleChange} required placeholder="Jane Doe" />
            </div>
            <div className="form-group">
              <label>Email</label>
              <input name="email" type="email" value={form.email} onChange={handleChange} required placeholder="you@example.com" />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input name="password" type="password" value={form.password} onChange={handleChange} required placeholder="••••••••" />
            </div>
            <button className="btn btn-primary" style={{ width: "100%" }} disabled={loading}>
              {loading ? "Registering…" : "Create Account"}
            </button>
          </form>
        )}

        {error && <p className="error-msg">{error}</p>}
      </div>
    </div>
  );
}
