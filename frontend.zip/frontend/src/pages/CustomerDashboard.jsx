import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import StatusBadge from "../components/StatusBadge";
import API from "../api/client";

const SERVICE_TYPES = ["CCTV", "Networking", "Maintenance", "Smart Home", "Access Control", "Tech Support"];
const PRIORITIES    = ["low", "medium", "high", "critical"];

const EMPTY_FORM = { service_type: "CCTV", title: "", description: "", location: "", priority: "medium" };

export default function CustomerDashboard() {
  const navigate = useNavigate();
  const [tickets, setTickets]         = useState([]);
  const [form, setForm]               = useState(EMPTY_FORM);
  const [showForm, setShowForm]       = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [loading, setLoading]         = useState(false);

  async function fetchTickets() {
    try {
      const { data } = await API.get("/tickets/my");
      setTickets(data);
    } catch {
      // silently ignore — auth guard handles session expiry
    }
  }

  useEffect(() => { fetchTickets(); }, []);

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSubmitError("");
    setLoading(true);
    try {
      await API.post("/tickets", form);
      setForm(EMPTY_FORM);
      setShowForm(false);
      fetchTickets();
    } catch (err) {
      setSubmitError(err.response?.data?.detail || "Failed to submit ticket");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar title="Customer Dashboard" />
      <div className="container">

        {/* ── New Request Button ── */}
        <div className="dash-header">
          <h2>My Service Requests</h2>
          <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>
            {showForm ? "Cancel" : "+ New Request"}
          </button>
        </div>

        {/* ── Submit Ticket Form ── */}
        {showForm && (
          <div className="card">
            <h3 style={{ marginBottom: "1rem", color: "#16213e" }}>Submit a New Service Request</h3>
            <form onSubmit={handleSubmit}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 1rem" }}>
                <div className="form-group">
                  <label>Service Type</label>
                  <select name="service_type" value={form.service_type} onChange={handleChange}>
                    {SERVICE_TYPES.map((s) => <option key={s}>{s}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Priority</label>
                  <select name="priority" value={form.priority} onChange={handleChange}>
                    {PRIORITIES.map((p) => <option key={p}>{p}</option>)}
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label>Title</label>
                <input name="title" value={form.title} onChange={handleChange} required placeholder="Brief summary of the issue" />
              </div>
              <div className="form-group">
                <label>Location</label>
                <input name="location" value={form.location} onChange={handleChange} required placeholder="Building / Floor / Room" />
              </div>
              <div className="form-group">
                <label>Description</label>
                <textarea name="description" value={form.description} onChange={handleChange} required placeholder="Describe the issue in detail…" />
              </div>
              {submitError && <p className="error-msg">{submitError}</p>}
              <button className="btn btn-success" disabled={loading}>
                {loading ? "Submitting…" : "Submit Request"}
              </button>
            </form>
          </div>
        )}

        {/* ── My Tickets Table ── */}
        <div className="card">
          {tickets.length === 0 ? (
            <p style={{ color: "#718096", textAlign: "center", padding: "2rem 0" }}>
              No service requests yet. Click "+ New Request" to get started.
            </p>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Service</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <th>Technician</th>
                    <th>Submitted</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {tickets.map((t) => (
                    <tr key={t.id}>
                      <td>{t.id}</td>
                      <td>{t.title}</td>
                      <td>{t.service_type}</td>
                      <td><StatusBadge value={t.priority} /></td>
                      <td><StatusBadge value={t.status} /></td>
                      <td>{t.assigned_technician || "—"}</td>
                      <td>{new Date(t.created_at).toLocaleDateString()}</td>
                      <td>
                        <button className="btn btn-primary btn-sm" onClick={() => navigate(`/tickets/${t.id}`)}>
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>
    </>
  );
}
